# CEO Texture Pack — Minecraft 1.21.4

Ten resource pack is built for Java Edition 1.21.4 (resource pack format 46).

## Komendy

- `/texture-pack-nadaj-miecz-1` ... `-14`
- `/texture-pack-nadaj-glowa-1` ... `-14`
- `/texture-pack-nadaj-klata-1` ... `-14`
- `/texture-pack-nadaj-spodnie-1` ... `-14`
- `/texture-pack-nadaj-buty-1` ... `-14`
- `/custom-txt-nadaj-muszla`
- `/custom-txt-nadaj-patyk`
- `/custom-txt-nadaj-zlote-jablko`
- `/custom-txt-nadaj-sniezka`

The custom item textures use transparent backgrounds.

### Ważne
The supplied armor images are GUI/item icons. This pack changes the item icon in inventory/hand. It does **not** create new worn-player armor UV textures from those screenshots. To make the armor also look custom when equipped, proper `humanoid` / `humanoid_leggings` armor layer PNGs are needed.
