# CEOTexture — gotowy projekt

- `plugin/` — źródła pluginu Paper 1.21.4 + `plugin.yml` + `config.yml`.
- `resourcepack/` — gotowy resource pack 1.21.4.

Najbezpieczniej nadać tylko CEO permission `ceotextur.ceo` (np. przez LuckPerms) albo wpisać nick CEO w `plugin/config.yml`.

## Instalacja
1. Wgraj zbudowany `ceo-texture-1.0.0.jar` do `plugins/`.
2. Wgraj ZIP z `resourcepack/` jako resource pack serwera.
3. Ustaw CEO w `plugins/CEOTexture/config.yml` lub nadaj permission `ceotextur.ceo`.
