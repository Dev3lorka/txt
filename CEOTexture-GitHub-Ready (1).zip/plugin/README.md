# CEOTexture — Minecraft 1.21.4

Plugin + resource pack do nadawania customowych modeli przedmiotom.

## Komendy

- `/texture-pack-nadaj-miecz-1` ... `-14`
- `/texture-pack-nadaj-glowa-1` ... `-14`
- `/texture-pack-nadaj-klata-1` ... `-14`
- `/texture-pack-nadaj-spodnie-1` ... `-14`
- `/texture-pack-nadaj-buty-1` ... `-14`
- `/custom-txt-nadaj-muszla`
- `/custom-txt-nadaj-patyk`
- `/custom-txt-nadaj-sniezka`
- `/custom-txt-nadaj-zlote-jablko`

Komenda działa na przedmiocie trzymanym w głównej ręce.

## CEO

Najbezpieczniej nadać tylko randze CEO permission:

`ceotextur.ceo`

Alternatywnie można wpisać nick CEO w `plugins/CEOTexture/config.yml`.

## Resource pack

Resource pack jest przeznaczony dla Java Edition 1.21.4 i korzysta z nowego `item_model`.

Uwaga: przesłane screeny zawierają ikony przedmiotów z GUI. W tej wersji paczka zmienia wygląd itemu w ekwipunku i w ręce. Jeśli chcesz, aby zbroja miała również osobną teksturę po założeniu na gracza, potrzebne są właściwe rozkładówki armor layer 1/layer 2 (a nie same ikonki z GUI).
