package pl.ceotextur;

import java.lang.reflect.*;
import java.util.*;

public final class CeoTexturePlugin extends org.bukkit.plugin.java.JavaPlugin {
    private final Set<String> ceoNames = new HashSet<>();
    private static final String NS = "ceotextur";

    @Override
    public void onEnable() {
        loadCeoNames();
        String[] commands = {
            "texture-pack-nadaj-miecz-1","texture-pack-nadaj-miecz-2","texture-pack-nadaj-miecz-3","texture-pack-nadaj-miecz-4",
            "texture-pack-nadaj-miecz-5","texture-pack-nadaj-miecz-6","texture-pack-nadaj-miecz-7","texture-pack-nadaj-miecz-8",
            "texture-pack-nadaj-miecz-9","texture-pack-nadaj-miecz-10","texture-pack-nadaj-miecz-11","texture-pack-nadaj-miecz-12",
            "texture-pack-nadaj-miecz-13","texture-pack-nadaj-miecz-14",
            "texture-pack-nadaj-glowa-1","texture-pack-nadaj-glowa-2","texture-pack-nadaj-glowa-3","texture-pack-nadaj-glowa-4",
            "texture-pack-nadaj-glowa-5","texture-pack-nadaj-glowa-6","texture-pack-nadaj-glowa-7","texture-pack-nadaj-glowa-8",
            "texture-pack-nadaj-glowa-9","texture-pack-nadaj-glowa-10","texture-pack-nadaj-glowa-11","texture-pack-nadaj-glowa-12",
            "texture-pack-nadaj-glowa-13","texture-pack-nadaj-glowa-14",
            "texture-pack-nadaj-klata-1","texture-pack-nadaj-klata-2","texture-pack-nadaj-klata-3","texture-pack-nadaj-klata-4",
            "texture-pack-nadaj-klata-5","texture-pack-nadaj-klata-6","texture-pack-nadaj-klata-7","texture-pack-nadaj-klata-8",
            "texture-pack-nadaj-klata-9","texture-pack-nadaj-klata-10","texture-pack-nadaj-klata-11","texture-pack-nadaj-klata-12",
            "texture-pack-nadaj-klata-13","texture-pack-nadaj-klata-14",
            "texture-pack-nadaj-spodnie-1","texture-pack-nadaj-spodnie-2","texture-pack-nadaj-spodnie-3","texture-pack-nadaj-spodnie-4",
            "texture-pack-nadaj-spodnie-5","texture-pack-nadaj-spodnie-6","texture-pack-nadaj-spodnie-7","texture-pack-nadaj-spodnie-8",
            "texture-pack-nadaj-spodnie-9","texture-pack-nadaj-spodnie-10","texture-pack-nadaj-spodnie-11","texture-pack-nadaj-spodnie-12",
            "texture-pack-nadaj-spodnie-13","texture-pack-nadaj-spodnie-14",
            "texture-pack-nadaj-buty-1","texture-pack-nadaj-buty-2","texture-pack-nadaj-buty-3","texture-pack-nadaj-buty-4",
            "texture-pack-nadaj-buty-5","texture-pack-nadaj-buty-6","texture-pack-nadaj-buty-7","texture-pack-nadaj-buty-8",
            "texture-pack-nadaj-buty-9","texture-pack-nadaj-buty-10","texture-pack-nadaj-buty-11","texture-pack-nadaj-buty-12",
            "texture-pack-nadaj-buty-13","texture-pack-nadaj-buty-14",
            "custom-txt-nadaj-muszla","custom-txt-nadaj-patyk","custom-txt-nadaj-sniezka","custom-txt-nadaj-zlote-jablko"
        };
        for (String c : commands) register(c);
        getLogger().info("CEO Texture 1.21.4 wlaczony. Komendy tylko dla CEO z config.yml.");
    }

    private void register(String name) {
        try {
            Object cmd = getCommand(name);
            if (cmd == null) { getLogger().warning("Brak komendy w plugin.yml: " + name); return; }
            Method setExecutor = cmd.getClass().getMethod("setExecutor", org.bukkit.command.CommandExecutor.class);
            setExecutor.invoke(cmd, new Executor());
        } catch (Throwable t) { getLogger().severe("Nie mozna zarejestrowac " + name + ": " + t); }
    }

    private void loadCeoNames() {
        saveDefaultConfig();
        ceoNames.clear();
        try {
            Object cfg = getConfig();
            Object list = cfg.getClass().getMethod("get", String.class).invoke(cfg, "ceo-nicknames");
            if (list instanceof List<?>) for (Object x : (List<?>) list) ceoNames.add(String.valueOf(x).toLowerCase(Locale.ROOT));
        } catch (Throwable t) { getLogger().warning("Nie udalo sie wczytac config.yml: " + t); }
    }

    private final class Executor implements org.bukkit.command.CommandExecutor {
        @Override public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
            try {
                if (!(sender instanceof org.bukkit.entity.Player)) { sender.sendMessage("§cTylko gracz moze uzyc tej komendy."); return true; }
                Object player = sender;
                String name = String.valueOf(player.getClass().getMethod("getName").invoke(player)).toLowerCase(Locale.ROOT);
                boolean allowedByName = ceoNames.contains(name);
                boolean allowedByPermission = (Boolean) sender.getClass().getMethod("hasPermission", String.class).invoke(sender, "ceotextur.ceo");
                if (!allowedByName && !allowedByPermission) { sender.sendMessage("§cTylko CEO moze uzywac tych komend."); return true; }
                String[] p = label.split("-");
                String full = label.toLowerCase(Locale.ROOT);
                String model;
                if (full.startsWith("custom-txt-nadaj-")) {
                    model = switch (full.substring("custom-txt-nadaj-".length())) {
                        case "muszla" -> "muszla"; case "patyk" -> "patyk"; case "sniezka" -> "sniezka"; case "zlote-jablko" -> "zlote_jablko"; default -> null;
                    };
                    if (model == null) return true;
                    String mat = switch (model) { case "muszla" -> "NAUTILUS_SHELL"; case "patyk" -> "STICK"; case "zlote_jablko" -> "GOLDEN_APPLE"; default -> "SNOWBALL"; };
                    applyItemModel(player, mat, model, false);
                    return true;
                }
                String[] parts = full.split("-");
                String type = parts[3];
                int pos = Integer.parseInt(parts[4]);
                String mat;
                switch (type) {
                    case "miecz" -> mat = "DIAMOND_SWORD";
                    case "glowa" -> mat = "NETHERITE_HELMET";
                    case "klata" -> mat = "NETHERITE_CHESTPLATE";
                    case "spodnie" -> mat = "NETHERITE_LEGGINGS";
                    case "buty" -> mat = "NETHERITE_BOOTS";
                    default -> { sender.sendMessage("§cNieznany typ."); return true; }
                }
                applyItemModel(player, mat, type + "_" + pos, true);
                return true;
            } catch (Throwable t) { sender.sendMessage("§cBlad: " + t.getMessage()); t.printStackTrace(); return true; }
        }
    }

    private void applyItemModel(Object player, String expectedMaterial, String modelId, boolean armor) throws Exception {
        Object inv = player.getClass().getMethod("getInventory").invoke(player);
        Object item = inv.getClass().getMethod("getItemInMainHand").invoke(inv);
        if (item == null || String.valueOf(item.getClass().getMethod("getType").invoke(item)).equals("AIR")) {
            player.getClass().getMethod("sendMessage", String.class).invoke(player, "§cTrzymaj przedmiot w glownej rece."); return;
        }
        String actual = String.valueOf(item.getClass().getMethod("getType").invoke(item));
        if (armor && !isArmorType(actual, expectedMaterial, modelId)) {
            player.getClass().getMethod("sendMessage", String.class).invoke(player, "§cTrzymaj odpowiednia czesc zbroi w rece."); return;
        }
        if (!armor && !actual.equals(expectedMaterial) && !(modelId.startsWith("miecz_") && actual.endsWith("_SWORD"))) {
            player.getClass().getMethod("sendMessage", String.class).invoke(player, "§cTrzymaj odpowiedni przedmiot w rece."); return;
        }
        Object meta = item.getClass().getMethod("getItemMeta").invoke(item);
        Class<?> nk = Class.forName("org.bukkit.NamespacedKey");
        Object key = nk.getConstructor(org.bukkit.plugin.Plugin.class, String.class).newInstance(this, modelId);
        meta.getClass().getMethod("setItemModel", nk).invoke(meta, key);
        item.getClass().getMethod("setItemMeta", Class.forName("org.bukkit.inventory.meta.ItemMeta")).invoke(item, meta);
        inv.getClass().getMethod("setItemInMainHand", Class.forName("org.bukkit.inventory.ItemStack")).invoke(inv, item);
        player.getClass().getMethod("sendMessage", String.class).invoke(player, "§aNadano teksture: §f" + modelId);
    }

    private static Method findMethod(Class<?> c, String name, Class<?>... types) { try { return c.getMethod(name, types); } catch (Throwable ignored) { return null; } }

    private static boolean isArmorType(String actual, String expected, String model) {
        if (model.startsWith("glowa")) return actual.endsWith("_HELMET");
        if (model.startsWith("klata")) return actual.endsWith("_CHESTPLATE");
        if (model.startsWith("spodnie")) return actual.endsWith("_LEGGINGS");
        if (model.startsWith("buty")) return actual.endsWith("_BOOTS");
        return false;
    }
}
