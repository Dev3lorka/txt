# CEOTexture 1.1.0 — Minecraft 1.21.4

Updated plugin + resource pack for Paper 1.21.4.

- Full leather armor set for armor commands.
- Player/Steve head also accepted by `glowa-*`.
- Any vanilla sword for sword commands.
- Heart of the Sea, Stick, Snowball and Golden Apple for custom commands.
- Commands are available to OPs and to `ceotextur.ceo`.

After replacing the resource-pack ZIP on GitHub, update `resource-pack-sha1` in `server.properties`.
