# CEOTexture Plugin 1.1.0 — Paper 1.21.4

Only OPs can use the commands. The `ceotextur.ceo` permission is also accepted.

Armor commands require leather armor; `glowa` also accepts a player head (Steve/player head).
Sword commands accept any vanilla sword.
Custom commands require:
- muszla = HEART_OF_THE_SEA
- patyk = STICK
- sniezka = SNOWBALL
- zlote-jablko = GOLDEN_APPLE

The plugin uses public Paper/Bukkit `ItemMeta#setItemModel` and does not access CraftMetaItem internals.
