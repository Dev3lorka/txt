package pl.ceotextur;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class CeoTexturePlugin extends JavaPlugin {
    private static final String NS = "ceotextur";

    @Override
    public void onEnable() {
        String[] groups = {"miecz", "glowa", "klata", "spodnie", "buty"};
        for (String group : groups) {
            for (int i = 1; i <= 14; i++) register("texture-pack-nadaj-" + group + "-" + i);
        }
        register("custom-txt-nadaj-muszla");
        register("custom-txt-nadaj-patyk");
        register("custom-txt-nadaj-sniezka");
        register("custom-txt-nadaj-zlote-jablko");
        getLogger().info("CEOTexture 1.21.4: aktywny. Komendy sa dostepne dla OP (oraz ceotextur.ceo).");
    }

    private void register(String name) {
        Command cmd = getCommand(name);
        if (cmd == null) {
            getLogger().warning("Brak komendy w plugin.yml: " + name);
            return;
        }
        cmd.setExecutor(new TextureExecutor());
    }

    private final class TextureExecutor implements CommandExecutor {
        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cTej komendy moze uzyc tylko gracz.");
                return true;
            }
            if (!player.isOp() && !player.hasPermission("ceotextur.ceo")) {
                player.sendMessage("§cBrak uprawnien. Komendy sa tylko dla OP.");
                return true;
            }

            String full = label.toLowerCase(Locale.ROOT);
            if (full.startsWith("custom-txt-nadaj-")) {
                return applyCustom(player, full.substring("custom-txt-nadaj-".length()));
            }

            String[] parts = full.split("-");
            if (parts.length != 5) return true;
            String type = parts[3];
            int pos;
            try { pos = Integer.parseInt(parts[4]); } catch (NumberFormatException e) { return true; }
            if (pos < 1 || pos > 14) return true;

            Material expected = switch (type) {
                case "miecz" -> null; // any vanilla sword
                case "glowa" -> Material.LEATHER_HELMET; // leather set helmet; PLAYER_HEAD is also accepted below
                case "klata" -> Material.LEATHER_CHESTPLATE;
                case "spodnie" -> Material.LEATHER_LEGGINGS;
                case "buty" -> Material.LEATHER_BOOTS;
                default -> null;
            };
            if (!type.equals("miecz") && expected == null) return true;

            String model = type + "_" + pos;
            return applyModel(player, expected, model, type);
        }

        private boolean applyCustom(Player player, String which) {
            Material expected;
            String model;
            switch (which) {
                case "muszla" -> { expected = Material.HEART_OF_THE_SEA; model = "muszla"; }
                case "patyk" -> { expected = Material.STICK; model = "patyk"; }
                case "sniezka" -> { expected = Material.SNOWBALL; model = "sniezka"; }
                case "zlote-jablko" -> { expected = Material.GOLDEN_APPLE; model = "zlote_jablko"; }
                default -> { return true; }
            }
            return applyModel(player, expected, model, "custom");
        }

        private boolean applyModel(Player player, Material expected, String model, String type) {
            PlayerInventory inv = player.getInventory();
            ItemStack item = inv.getItemInMainHand();
            Material actual = item.getType();

            if (actual == Material.AIR) {
                player.sendMessage("§cTrzymaj przedmiot w glownej rece.");
                return true;
            }

            boolean valid;
            if (type.equals("miecz")) {
                valid = actual.name().endsWith("_SWORD");
            } else if (type.equals("glowa")) {
                // Supports the full leather set and a Steve/player head as requested.
                valid = actual == Material.LEATHER_HELMET || actual == Material.PLAYER_HEAD;
            } else {
                valid = actual == expected;
            }

            if (!valid) {
                player.sendMessage("§cZly przedmiot. Trzymaj: §f" + requiredText(type));
                return true;
            }

            ItemMeta meta = item.getItemMeta();
            if (meta == null) {
                player.sendMessage("§cTen przedmiot nie ma ItemMeta.");
                return true;
            }

            NamespacedKey key = new NamespacedKey(CeoTexturePlugin.this, model);
            meta.setItemModel(key);
            item.setItemMeta(meta);
            inv.setItemInMainHand(item);

            player.sendMessage("§aNadano teksture: §f" + model);
            return true;
        }

        private String requiredText(String type) {
            return switch (type) {
                case "miecz" -> "dowolny miecz";
                case "glowa" -> "skorzany helm lub glowe gracza Steve";
                case "klata" -> "skorzany napierśnik";
                case "spodnie" -> "skorzane spodnie";
                case "buty" -> "skorzane buty";
                case "custom" -> "odpowiedni przedmiot";
                default -> "odpowiedni przedmiot";
            };
        }
    }
}
