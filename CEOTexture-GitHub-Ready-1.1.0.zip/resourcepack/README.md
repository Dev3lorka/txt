# CEOTexture Resource Pack — Minecraft 1.21.4

Base items supported by the CEOTexture plugin:
- leather helmet / player head for `glowa-1..14`
- leather chestplate for `klata-1..14`
- leather leggings for `spodnie-1..14`
- leather boots for `buty-1..14`
- any vanilla sword for `miecz-1..14`
- Heart of the Sea for `custom-txt-nadaj-muszla`
- Stick for `custom-txt-nadaj-patyk`
- Snowball for `custom-txt-nadaj-sniezka`
- Golden Apple for `custom-txt-nadaj-zlote-jablko`

Uses the Minecraft 1.21.4 item-model system.
